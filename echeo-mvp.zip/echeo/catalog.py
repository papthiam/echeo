"""Catégories, modèles d'échéances et choix de rappels.

Les délais proposés sont des suggestions de rappel, pas des délais légaux : l'utilisateur doit
toujours vérifier la procédure et les délais auprès de l'administration compétente.
"""

CATEGORIES = {
    "sejour": "Séjour et visas",
    "identite": "Identité et passeport",
    "assurance": "Assurance et santé",
    "impots": "Impôts et finances",
    "vehicule": "Véhicule et permis",
    "logement": "Logement",
    "abonnement": "Abonnements et contrats",
    "autre": "Autre",
}

MODELS = [
    {"key": "titre_sejour", "title": "Renouvellement du titre de séjour", "category": "sejour", "remind_days": "180,90,30,7,0"},
    {"key": "visa", "title": "Expiration du visa", "category": "sejour", "remind_days": "90,30,7,0"},
    {"key": "passeport", "title": "Expiration du passeport", "category": "identite", "remind_days": "270,90,30,0"},
    {"key": "carte_identite", "title": "Expiration de la carte d'identité", "category": "identite", "remind_days": "180,60,14,0"},
    {"key": "assurance_sante", "title": "Renouvellement de l'assurance santé", "category": "assurance", "remind_days": "60,30,7,0"},
    {"key": "assurance_auto", "title": "Renouvellement de l'assurance auto", "category": "assurance", "remind_days": "60,30,7,0"},
    {"key": "impots", "title": "Déclaration d'impôts", "category": "impots", "remind_days": "60,30,7,0"},
    {"key": "permis", "title": "Renouvellement du permis de conduire", "category": "vehicule", "remind_days": "90,30,0"},
    {"key": "controle_technique", "title": "Contrôle technique du véhicule", "category": "vehicule", "remind_days": "30,7,0"},
    {"key": "bail", "title": "Fin ou renouvellement du bail", "category": "logement", "remind_days": "120,60,30,0"},
    {"key": "abonnement", "title": "Renouvellement d'un abonnement", "category": "abonnement", "remind_days": "14,3,0"},
]
MODEL_BY_KEY = {m["key"]: m for m in MODELS}

REMIND_CHOICES = [
    (270, "9 mois avant"),
    (180, "6 mois avant"),
    (120, "4 mois avant"),
    (90, "3 mois avant"),
    (60, "2 mois avant"),
    (30, "1 mois avant"),
    (14, "2 semaines avant"),
    (7, "1 semaine avant"),
    (3, "3 jours avant"),
    (1, "la veille"),
    (0, "le jour même"),
]
VALID_REMIND = {d for d, _ in REMIND_CHOICES}
