# Échéo — suivi des échéances administratives (MVP)

Application web (Flask + SQLite) : comptes par lien magique, échéances avec modèles, rappels email automatiques,
documents chiffrés, abonnement (essai 14 jours, plans Gratuit / Essentiel / Famille), agenda .ics, export et
suppression des données (RGPD).

## Lancer en local

```bash
pip install -r requirements.txt
python app.py                 # http://localhost:5000
python -m pytest -q           # 25 tests
```

Sans configuration email, les messages (liens de connexion, rappels) sont écrits dans `data/outbox/*.eml` :
ouvrez le dernier fichier pour récupérer votre lien de connexion en local.

## Configuration (variables d'environnement, voir `.env.example`)

| Variable | Rôle |
|---|---|
| `BASE_URL` | URL publique (utilisée dans les emails), ex. `https://echeo.example.com` |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM` | Envoi des emails (Resend, Brevo, Mailgun, etc. en SMTP) |
| `SECRET_KEY`, `FILE_ENCRYPTION_KEY` | Générées automatiquement dans `data/` si absentes. **Sauvegardez-les** : sans la clé de fichiers, les documents sont illisibles |
| `WEBHOOK_SECRET` | Secret de signature du webhook de paiement (sans lui, le webhook est refusé) |
| `CHECKOUT_ESSENTIAL_MONTH/YEAR`, `CHECKOUT_FAMILY_MONTH/YEAR` | Liens de paiement hébergés de votre prestataire |
| `SECURE_COOKIES=1` | À activer en HTTPS |
| `LEGAL_ENTITY`, `CONTACT_EMAIL` | Affichés dans les pages légales |
| `ECHEO_DATA_DIR` | Dossier des données (base, documents, clés). Par défaut `./data` |

## Automatisation (rappels)

Les rappels ne partent que si le script tourne chaque jour. Sur votre serveur (`crontab -e`) :

```cron
# Rappels d'échéances, tous les jours à 07:00
0 7 * * *  cd /chemin/echeo && /usr/bin/python3 reminders.py >> data/reminders.log 2>&1
# Résumé mensuel « vos 3 prochaines échéances », le 1er du mois à 08:00
0 8 1 * *  cd /chemin/echeo && /usr/bin/python3 reminders.py --digest >> data/reminders.log 2>&1
```

- Un envoi échoué est retenté au passage suivant ; le script sort en code 1 s'il y a eu des échecs.
- `GET /healthz` indique `reminders_stale: true` si le script n'a pas tourné depuis plus de 26 h :
  branchez-y un moniteur gratuit (UptimeRobot, Healthchecks.io) pour être alerté.
- `python kpis.py` affiche inscrits, activation, abonnés, MRR, conversion et rappels envoyés.

## Paiement

Le serveur expose `POST /webhooks/payments`, signé en HMAC-SHA256 (en-tête `X-Signature`, corps brut, secret
`WEBHOOK_SECRET`) :

```json
{"event": "subscription_active", "email": "client@example.com", "plan": "essential",
 "interval": "month", "paid_until": "2026-12-07", "customer_ref": "cus_123"}
```

`subscription_expired` coupe l'accès payant. Les prestataires (Lemon Squeezy, Paddle, Stripe) envoient chacun leur
propre format : il faut un petit mapping (environ 30 lignes) entre leur payload et celui-ci. Le champ `paid_until`
est la source de vérité : l'accès payant dure jusqu'à cette date, ce qui gère aussi les résiliations.

## Déploiement simple

Un petit VPS (5 à 6 $/mois) ou une plateforme avec disque persistant (le dossier `data/` doit survivre aux redéploiements) :

```bash
gunicorn -w 2 -b 0.0.0.0:8000 "app:create_app()"   # derrière Caddy ou Nginx en HTTPS
```

Sauvegardez `data/` chaque nuit (base, documents chiffrés, clés), et testez une restauration.

## Ce qui est inclus / pas encore inclus

Inclus : lien magique à usage unique (non consommé par les scanners d'email), protection CSRF, en-têtes de sécurité
et CSP, limitation des demandes de lien, documents chiffrés (Fernet) avec contrôle du type réel de fichier et quota,
isolation stricte entre utilisateurs, pages légales (brouillon), export et suppression de compte.

Pas encore fait (v1.1 et suivantes) : rappels WhatsApp/SMS, partage familial, double authentification, lecture
automatique des dates sur les scans (OCR), application installable (PWA), limitation par adresse IP (à mettre au
niveau de Cloudflare ou du proxy), fuseaux horaires par utilisateur (les rappels suivent la date du serveur),
plusieurs serveurs (SQLite convient jusqu'à quelques milliers d'utilisateurs sur une seule machine).

## Avant d'encaisser un premier paiement

1. Faire relire les pages `/page/confidentialite` et `/page/conditions` par un juriste et compléter les crochets.
2. Configurer SPF, DKIM et DMARC sur le domaine d'envoi (sinon les rappels finissent en spam).
3. Envoyer un vrai rappel à votre propre adresse et vérifier la réception.
4. Tester un paiement complet de bout en bout avec votre prestataire (mode test).
