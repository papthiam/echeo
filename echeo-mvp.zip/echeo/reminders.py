#!/usr/bin/env python3
"""Moteur de rappels d'Échéo, à lancer une fois par jour (cron).

    python reminders.py            # rappels d'échéances
    python reminders.py --digest   # résumé mensuel « vos 3 prochaines échéances » (le 1er du mois)

Règles :
- Un rappel est dû dès que le nombre de jours restants est inférieur ou égal à un des délais choisis.
- Si plusieurs délais sont atteints d'un coup (échéance créée tardivement), un seul email part, pour le plus urgent ;
  les autres sont marqués « skipped » pour ne pas inonder l'utilisateur.
- Un envoi qui échoue n'est pas enregistré : il est retenté au prochain passage.
- Changer la date d'une échéance réarme automatiquement ses rappels (la date fait partie de la clé).
- Les échéances dépassées de plus de 30 jours ne déclenchent plus d'email.
"""
import argparse
import os
import sys
from datetime import date, datetime, timedelta, timezone

import db as dbm
from config import load_config
from mailer import send_email

STALE_AFTER_DAYS = 30


def parse_days(raw):
    out = set()
    for part in (raw or "").split(","):
        part = part.strip()
        if part.isdigit():
            out.add(int(part))
    return sorted(out, reverse=True)


def headline(left):
    if left > 1:
        return f"Dans {left} jours"
    if left == 1:
        return "Demain"
    if left == 0:
        return "Aujourd'hui"
    if left == -1:
        return "En retard d'1 jour"
    return f"En retard de {-left} jours"


def build_reminder(cfg, row, left):
    due = date.fromisoformat(row["due_date"]).strftime("%d/%m/%Y")
    unsub = f"{cfg['BASE_URL']}/unsubscribe/{row['unsub_token']}"
    subject = f"{headline(left)} : {row['title']}"
    lines = [
        "Bonjour,",
        "",
        f"Rappel d'échéance : {headline(left).lower()}.",
        "",
        f"  Échéance : {row['title']}",
        f"  Date limite : {due}",
    ]
    if row["person"]:
        lines.append(f"  Personne concernée : {row['person']}")
    if row["country"]:
        lines.append(f"  Pays : {row['country']}")
    lines += [
        "",
        f"Détails et documents : {cfg['BASE_URL']}/deadlines/{row['id']}",
        "",
        "Vérifiez la procédure et les délais auprès de l'administration compétente.",
        "",
        "— Échéo",
        f"Ne plus recevoir ces rappels : {unsub}",
    ]
    headers = {
        "List-Unsubscribe": f"<{unsub}>",
        "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
    }
    return subject, "\n".join(lines), headers


def run_reminders(cfg, today=None, conn=None, mailer=send_email):
    today = today or date.today()
    own = conn is None
    conn = conn or dbm.connect(cfg["DB_PATH"])
    stats = {"sent": 0, "skipped": 0, "failed": 0}
    rows = conn.execute(
        "SELECT d.*, u.email, u.unsub_token FROM deadlines d JOIN users u ON u.id = d.user_id"
        " WHERE d.done = 0 AND u.reminders_enabled = 1"
    ).fetchall()
    for row in rows:
        try:
            left = (date.fromisoformat(row["due_date"]) - today).days
        except ValueError:
            continue
        reached = [o for o in parse_days(row["remind_days"]) if left <= o]
        if not reached:
            continue
        already = {
            r[0] for r in conn.execute(
                "SELECT offset_days FROM reminders_sent WHERE deadline_id=? AND due_date=?",
                (row["id"], row["due_date"]),
            )
        }
        pending = [o for o in reached if o not in already]
        if not pending:
            continue
        target = min(pending)
        now = dbm.utc_iso()

        if left < -STALE_AFTER_DAYS:
            for o in pending:
                conn.execute(
                    "INSERT OR IGNORE INTO reminders_sent VALUES (?,?,?,?,?)",
                    (row["id"], o, row["due_date"], "skipped", now),
                )
            stats["skipped"] += len(pending)
            conn.commit()
            continue

        subject, text, headers = build_reminder(cfg, row, left)
        if not mailer(cfg, row["email"], subject, text, headers):
            stats["failed"] += 1
            continue
        for o in pending:
            conn.execute(
                "INSERT OR IGNORE INTO reminders_sent VALUES (?,?,?,?,?)",
                (row["id"], o, row["due_date"], "sent" if o == target else "skipped", now),
            )
        conn.commit()
        stats["sent"] += 1
        stats["skipped"] += len(pending) - 1

    if own:
        conn.close()
    return stats


def run_digest(cfg, today=None, conn=None, mailer=send_email):
    """Email mensuel de rétention : les 3 prochaines échéances des 180 jours à venir."""
    today = today or date.today()
    own = conn is None
    conn = conn or dbm.connect(cfg["DB_PATH"])
    key = f"digest_{today:%Y-%m}"
    stats = {"sent": 0, "failed": 0}
    horizon = (today + timedelta(days=180)).isoformat()
    for user in conn.execute("SELECT * FROM users WHERE reminders_enabled = 1").fetchall():
        if conn.execute("SELECT 1 FROM events WHERE user_id=? AND name=?", (user["id"], key)).fetchone():
            continue
        items = conn.execute(
            "SELECT * FROM deadlines WHERE user_id=? AND done=0 AND due_date>=? AND due_date<=?"
            " ORDER BY due_date LIMIT 3",
            (user["id"], today.isoformat(), horizon),
        ).fetchall()
        if not items:
            continue
        lines = ["Bonjour,", "", "Voici vos prochaines échéances :", ""]
        for it in items:
            left = (date.fromisoformat(it["due_date"]) - today).days
            lines.append(f"  • {it['title']} : {date.fromisoformat(it['due_date']):%d/%m/%Y} ({headline(left).lower()})")
        unsub = f"{cfg['BASE_URL']}/unsubscribe/{user['unsub_token']}"
        lines += ["", f"Voir toutes vos échéances : {cfg['BASE_URL']}/dashboard", "", "— Échéo",
                  f"Ne plus recevoir ces emails : {unsub}"]
        headers = {"List-Unsubscribe": f"<{unsub}>", "List-Unsubscribe-Post": "List-Unsubscribe=One-Click"}
        if mailer(cfg, user["email"], "Vos prochaines échéances", "\n".join(lines), headers):
            dbm.track(conn, user["id"], key)
            conn.commit()
            stats["sent"] += 1
        else:
            stats["failed"] += 1
    if own:
        conn.close()
    return stats


def main():
    parser = argparse.ArgumentParser(description="Rappels d'échéances Échéo")
    parser.add_argument("--digest", action="store_true", help="envoyer le résumé mensuel")
    args = parser.parse_args()
    cfg = load_config()
    dbm.init_db(cfg["DB_PATH"])
    stats = run_digest(cfg) if args.digest else run_reminders(cfg)
    print(stats)
    if not args.digest:
        with open(os.path.join(cfg["DATA_DIR"], "last_reminder_run"), "w", encoding="utf-8") as f:
            f.write(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    sys.exit(1 if stats["failed"] else 0)


if __name__ == "__main__":
    main()
