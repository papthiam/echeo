"""Configuration d'Échéo : variables d'environnement avec valeurs par défaut sûres."""
import os
import secrets

from cryptography.fernet import Fernet

DEFAULT_REMIND = "90,30,7,0"


def _persisted(env_value, path, factory):
    """Retourne la valeur d'environnement, sinon une valeur générée et conservée dans un fichier 0600."""
    if env_value:
        return env_value
    try:
        with open(path, "r", encoding="utf-8") as f:
            value = f.read().strip()
            if value:
                return value
    except FileNotFoundError:
        pass
    value = factory()
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(value)
    return value


def load_config(env=None):
    merged = dict(os.environ)
    if env:
        merged.update(env)
    here = os.path.dirname(os.path.abspath(__file__))
    data_dir = merged.get("ECHEO_DATA_DIR") or os.path.join(here, "data")
    os.makedirs(data_dir, exist_ok=True)
    upload_dir = merged.get("ECHEO_UPLOAD_DIR") or os.path.join(data_dir, "uploads")
    os.makedirs(upload_dir, exist_ok=True)

    return {
        "DATA_DIR": data_dir,
        "DB_PATH": merged.get("ECHEO_DB") or os.path.join(data_dir, "echeo.db"),
        "UPLOAD_DIR": upload_dir,
        "OUTBOX_DIR": merged.get("ECHEO_OUTBOX_DIR") or os.path.join(data_dir, "outbox"),
        "SECRET_KEY": _persisted(
            merged.get("SECRET_KEY"), os.path.join(data_dir, "secret.key"), lambda: secrets.token_hex(32)
        ),
        "FILE_KEY": _persisted(
            merged.get("FILE_ENCRYPTION_KEY"),
            os.path.join(data_dir, "file.key"),
            lambda: Fernet.generate_key().decode(),
        ),
        "BASE_URL": (merged.get("BASE_URL") or "http://localhost:5000").rstrip("/"),
        "MAIL_FROM": merged.get("MAIL_FROM") or "Échéo <no-reply@localhost>",
        "SMTP_HOST": merged.get("SMTP_HOST") or "",
        "SMTP_PORT": merged.get("SMTP_PORT") or "587",
        "SMTP_USER": merged.get("SMTP_USER") or "",
        "SMTP_PASSWORD": merged.get("SMTP_PASSWORD") or "",
        "WEBHOOK_SECRET": merged.get("WEBHOOK_SECRET") or "",
        "TRIAL_DAYS": int(merged.get("TRIAL_DAYS") or 14),
        "SESSION_COOKIE_SECURE": merged.get("SECURE_COOKIES", "0") == "1",
        "LEGAL_ENTITY": merged.get("LEGAL_ENTITY") or "[NOM DE L'ÉDITEUR À COMPLÉTER]",
        "CONTACT_EMAIL": merged.get("CONTACT_EMAIL") or "[EMAIL DE CONTACT À COMPLÉTER]",
        "CHECKOUT_URLS": {
            ("essential", "month"): merged.get("CHECKOUT_ESSENTIAL_MONTH", ""),
            ("essential", "year"): merged.get("CHECKOUT_ESSENTIAL_YEAR", ""),
            ("family", "month"): merged.get("CHECKOUT_FAMILY_MONTH", ""),
            ("family", "year"): merged.get("CHECKOUT_FAMILY_YEAR", ""),
        },
    }
