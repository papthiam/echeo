"""Envoi d'emails : SMTP si configuré, sinon écriture de fichiers .eml dans un dossier « outbox » (mode développement)."""
import os
import re
import smtplib
import ssl
import sys
import time
from email.message import EmailMessage
from email.utils import formatdate, make_msgid


def send_email(config, to, subject, text, headers=None):
    """Retourne True si le message a été remis au serveur (ou écrit en outbox), False sinon."""
    msg = EmailMessage()
    msg["From"] = config["MAIL_FROM"]
    msg["To"] = to
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=False)
    msg["Message-ID"] = make_msgid(domain="echeo.local")
    for key, value in (headers or {}).items():
        msg[key] = value
    msg.set_content(text)

    host = config.get("SMTP_HOST")
    if not host:
        outbox = config["OUTBOX_DIR"]
        os.makedirs(outbox, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9]+", "_", to)[:40]
        path = os.path.join(outbox, f"{time.time_ns()}-{safe}.eml")
        with open(path, "wb") as f:
            f.write(msg.as_bytes())
        return True

    try:
        port = int(config.get("SMTP_PORT") or 587)
        context = ssl.create_default_context()
        if port == 465:
            server = smtplib.SMTP_SSL(host, port, timeout=20, context=context)
        else:
            server = smtplib.SMTP(host, port, timeout=20)
            server.starttls(context=context)
        with server:
            if config.get("SMTP_USER"):
                server.login(config["SMTP_USER"], config.get("SMTP_PASSWORD", ""))
            server.send_message(msg)
        return True
    except Exception as exc:  # noqa: BLE001 - on veut tout capter et réessayer au prochain passage
        print(f"[mailer] échec d'envoi à {to}: {exc}", file=sys.stderr)
        return False
