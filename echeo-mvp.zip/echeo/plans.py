"""Plans, limites et calcul du plan effectif d'un utilisateur."""
from datetime import date

PLANS = {
    "free": {"label": "Gratuit", "max_deadlines": 3, "storage_mb": 0, "price_month": 0.0, "price_year": 0.0},
    "essential": {"label": "Essentiel", "max_deadlines": None, "storage_mb": 1024, "price_month": 4.99, "price_year": 39.0},
    "family": {"label": "Famille", "max_deadlines": None, "storage_mb": 5120, "price_month": 8.99, "price_year": 69.0},
}


def effective_plan(user, today=None):
    """Retourne (plan, état) où état est 'paid', 'trial' ou 'free'."""
    today = (today or date.today()).isoformat()
    if user["plan"] in ("essential", "family") and user["paid_until"] and user["paid_until"] >= today:
        return user["plan"], "paid"
    if user["trial_ends_at"] >= today:
        return "essential", "trial"
    return "free", "free"


def monthly_value(plan, interval):
    info = PLANS.get(plan)
    if not info:
        return 0.0
    return info["price_year"] / 12 if interval == "year" else info["price_month"]
