import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402


@pytest.fixture()
def app(tmp_path):
    return create_app({
        "ECHEO_DATA_DIR": str(tmp_path),
        "WEBHOOK_SECRET": "test-secret",
        "BASE_URL": "http://test",
        "SMTP_HOST": "",
    })


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf_of(client, path="/login"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


def read_outbox(app):
    folder = app.config["OUTBOX_DIR"]
    if not os.path.isdir(folder):
        return []
    items = []
    for name in sorted(os.listdir(folder)):
        with open(os.path.join(folder, name), encoding="utf-8") as f:
            items.append(f.read())
    return items


def login(client, app, email="alice@example.com"):
    before = len(read_outbox(app))
    client.post("/login", data={"email": email, "csrf": csrf_of(client)})
    mails = read_outbox(app)
    assert len(mails) == before + 1
    token = re.search(r"/auth/([\w-]+)", mails[-1]).group(1)
    client.get(f"/auth/{token}")
    resp = client.post(f"/auth/{token}", data={"csrf": csrf_of(client, f"/auth/{token}")})
    assert resp.status_code == 302
    return token
