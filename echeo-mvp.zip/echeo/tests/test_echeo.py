import hashlib
import hmac
import json
import os
import re
from datetime import date, timedelta

import db as dbm
import kpis
import reminders
from conftest import csrf_of, login, read_outbox


def iso_in(days):
    return (date.today() + timedelta(days=days)).isoformat()


def add_deadline(client, title="Passeport", days=100, remind=("90", "30", "7", "0"), person="Alice"):
    resp = client.post("/deadlines/new", data={
        "csrf": csrf_of(client, "/deadlines/new"), "title": title, "due_date": iso_in(days),
        "category": "identite", "person": person, "remind": list(remind),
    })
    return resp


def conn_of(app):
    return dbm.connect(app.config["DB_PATH"])


# ---------------------------------------------------------------- authentification
def test_magic_link_is_single_use_and_not_consumed_by_get(app, client):
    token = login(client, app)
    assert client.get("/dashboard").status_code == 200
    # Deuxième utilisation du même lien : refusée.
    other = app.test_client()
    assert "Lien expiré" in other.get(f"/auth/{token}").get_data(as_text=True)
    resp = other.post(f"/auth/{token}", data={"csrf": csrf_of(other, "/login")})
    assert resp.status_code == 302 and "/login" in resp.headers["Location"]
    assert other.get("/dashboard").status_code == 302


def test_login_does_not_reveal_whether_account_exists(app, client):
    login(client, app, "known@example.com")
    c2 = app.test_client()
    r1 = c2.post("/login", data={"email": "known@example.com", "csrf": csrf_of(c2)})
    r2 = c2.post("/login", data={"email": "unknown@example.com", "csrf": csrf_of(c2)})
    assert r1.status_code == r2.status_code == 302
    assert r1.headers["Location"] == r2.headers["Location"]


def test_login_rate_limit_per_email(app):
    c = app.test_client()
    for _ in range(8):
        c.post("/login", data={"email": "spam@example.com", "csrf": csrf_of(c)})
    assert len([m for m in read_outbox(app) if "spam@example.com" in m]) == 5


def test_csrf_required(client):
    assert client.post("/login", data={"email": "a@example.com"}).status_code == 400


def test_dashboard_requires_login(client):
    assert client.get("/dashboard").status_code == 302


# ------------------------------------------------------------------ échéances
def test_create_and_isolation_between_users(app, client):
    login(client, app, "alice@example.com")
    resp = add_deadline(client)
    assert resp.status_code == 302
    detail = resp.headers["Location"]
    assert "Passeport" in client.get("/dashboard").get_data(as_text=True)

    bob = app.test_client()
    login(bob, app, "bob@example.com")
    assert bob.get(detail).status_code == 404
    assert "Passeport" not in bob.get("/dashboard").get_data(as_text=True)


def test_invalid_form_rejected(app, client):
    login(client, app)
    resp = client.post("/deadlines/new", data={"csrf": csrf_of(client, "/deadlines/new"), "title": "", "due_date": "pas-une-date"})
    assert resp.status_code == 400


def test_free_plan_limit_after_trial(app, client):
    login(client, app)
    conn = conn_of(app)
    conn.execute("UPDATE users SET trial_ends_at=?", (iso_in(-1),))
    conn.commit()
    for i in range(3):
        assert add_deadline(client, title=f"Item {i}").status_code == 302
    resp = client.post("/deadlines/new", data={
        "csrf": csrf_of(client, "/dashboard"), "title": "Quatrième", "due_date": iso_in(100),
        "category": "identite", "remind": ["30"],
    })
    assert resp.status_code == 302 and "/billing" in resp.headers["Location"]
    assert client.get("/deadlines/new").status_code == 302
    assert conn.execute("SELECT COUNT(*) FROM deadlines").fetchone()[0] == 3


# ----------------------------------------------------------------- documents
def test_upload_is_encrypted_and_downloadable(app, client):
    login(client, app)
    did = re.search(r"/deadlines/(\d+)", add_deadline(client).headers["Location"]).group(1)
    pdf = b"%PDF-1.4\nSECRET-PASSPORT-CONTENT\n%%EOF"
    resp = client.post(f"/deadlines/{did}/upload", data={
        "csrf": csrf_of(client, f"/deadlines/{did}"), "file": (__import__("io").BytesIO(pdf), "passeport.pdf"),
    }, content_type="multipart/form-data")
    assert resp.status_code == 302
    on_disk = [os.path.join(r, f) for r, _, fs in os.walk(app.config["UPLOAD_DIR"]) for f in fs]
    assert len(on_disk) == 1
    with open(on_disk[0], "rb") as f:
        assert b"SECRET-PASSPORT-CONTENT" not in f.read()
    att_id = conn_of(app).execute("SELECT id FROM attachments").fetchone()[0]
    got = client.get(f"/files/{att_id}")
    assert got.status_code == 200 and got.data == pdf
    # Un autre utilisateur ne peut pas le télécharger.
    bob = app.test_client()
    login(bob, app, "bob@example.com")
    assert bob.get(f"/files/{att_id}").status_code == 404


def test_upload_rejects_fake_pdf(app, client):
    login(client, app)
    did = re.search(r"/deadlines/(\d+)", add_deadline(client).headers["Location"]).group(1)
    client.post(f"/deadlines/{did}/upload", data={
        "csrf": csrf_of(client, f"/deadlines/{did}"), "file": (__import__("io").BytesIO(b"MZ-not-a-pdf"), "x.pdf"),
    }, content_type="multipart/form-data")
    assert conn_of(app).execute("SELECT COUNT(*) FROM attachments").fetchone()[0] == 0


def test_delete_account_removes_everything(app, client):
    login(client, app)
    did = re.search(r"/deadlines/(\d+)", add_deadline(client).headers["Location"]).group(1)
    client.post(f"/deadlines/{did}/upload", data={
        "csrf": csrf_of(client, f"/deadlines/{did}"), "file": (__import__("io").BytesIO(b"%PDF-1.4 x"), "a.pdf"),
    }, content_type="multipart/form-data")
    client.post("/settings/delete-account", data={"csrf": csrf_of(client, "/settings"), "confirm_email": "alice@example.com"})
    conn = conn_of(app)
    assert conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM deadlines").fetchone()[0] == 0
    assert [f for _, _, fs in os.walk(app.config["UPLOAD_DIR"]) for f in fs] == []


# ------------------------------------------------------------------- rappels
def make_cfg(app):
    return dict(app.config)


def test_reminder_sent_once_then_idempotent(app, client):
    login(client, app)
    add_deadline(client, days=30)
    cfg = make_cfg(app)
    before = len(read_outbox(app))
    assert reminders.run_reminders(cfg)["sent"] == 1
    assert reminders.run_reminders(cfg)["sent"] == 0
    mails = read_outbox(app)[before:]
    assert len(mails) == 1 and "Dans 30 jours" in mails[0] and "Passeport" in mails[0]
    assert "List-Unsubscribe" in mails[0]


def test_late_creation_sends_single_most_urgent_reminder(app, client):
    login(client, app)
    add_deadline(client, days=20)  # J-90 et J-30 déjà passés
    cfg = make_cfg(app)
    before = len(read_outbox(app))
    stats = reminders.run_reminders(cfg)
    assert stats["sent"] == 1 and stats["skipped"] == 1
    assert len(read_outbox(app)) == before + 1
    assert reminders.run_reminders(cfg)["sent"] == 0


def test_reminders_follow_the_calendar_day_by_day(app, client):
    login(client, app)
    add_deadline(client, days=100)
    cfg = make_cfg(app)
    sent_on = []
    for offset in range(0, 101):
        today = date.today() + timedelta(days=offset)
        if reminders.run_reminders(cfg, today=today)["sent"]:
            sent_on.append((date.today() + timedelta(days=100) - today).days)
    assert sent_on == [90, 30, 7, 0]


def test_failed_send_is_retried(app, client):
    login(client, app)
    add_deadline(client, days=30)
    cfg = make_cfg(app)
    assert reminders.run_reminders(cfg, mailer=lambda *a, **k: False) == {"sent": 0, "skipped": 0, "failed": 1}
    assert reminders.run_reminders(cfg)["sent"] == 1


def test_changing_the_date_rearms_reminders(app, client):
    login(client, app)
    resp = add_deadline(client, days=30)
    did = re.search(r"/deadlines/(\d+)", resp.headers["Location"]).group(1)
    cfg = make_cfg(app)
    assert reminders.run_reminders(cfg)["sent"] == 1
    client.post(f"/deadlines/{did}/edit", data={
        "csrf": csrf_of(client, f"/deadlines/{did}/edit"), "title": "Passeport", "due_date": iso_in(7),
        "category": "identite", "remind": ["30", "7"],
    })
    assert reminders.run_reminders(cfg)["sent"] == 1


def test_done_and_unsubscribed_get_no_reminders(app, client):
    login(client, app)
    resp = add_deadline(client, days=7)
    did = re.search(r"/deadlines/(\d+)", resp.headers["Location"]).group(1)
    client.post(f"/deadlines/{did}/done", data={"csrf": csrf_of(client, f"/deadlines/{did}")})
    cfg = make_cfg(app)
    assert reminders.run_reminders(cfg)["sent"] == 0
    client.post(f"/deadlines/{did}/done", data={"csrf": csrf_of(client, f"/deadlines/{did}")})  # rouvre
    token = conn_of(app).execute("SELECT unsub_token FROM users").fetchone()[0]
    assert app.test_client().post(f"/unsubscribe/{token}").status_code == 200  # sans CSRF : lien secret
    assert reminders.run_reminders(cfg)["sent"] == 0


def test_digest_sent_once_per_month(app, client):
    login(client, app)
    add_deadline(client, days=45)
    cfg = make_cfg(app)
    assert reminders.run_digest(cfg)["sent"] == 1
    assert reminders.run_digest(cfg)["sent"] == 0


# ------------------------------------------------------- paiement et abonnement
def sign(body):
    return hmac.new(b"test-secret", body, hashlib.sha256).hexdigest()


def test_webhook_rejects_bad_signature(client):
    body = json.dumps({"event": "subscription_active", "email": "a@example.com", "plan": "essential"}).encode()
    assert client.post("/webhooks/payments", data=body, headers={"X-Signature": "nope"}).status_code == 401


def test_webhook_activates_plan_and_unlocks_features(app, client):
    login(client, app, "alice@example.com")
    conn = conn_of(app)
    conn.execute("UPDATE users SET trial_ends_at=?", (iso_in(-1),))
    conn.commit()
    assert "Gratuit" in client.get("/billing").get_data(as_text=True)
    body = json.dumps({
        "event": "subscription_active", "email": "alice@example.com", "plan": "essential",
        "interval": "year", "paid_until": iso_in(365), "customer_ref": "cus_1",
    }).encode()
    resp = client.post("/webhooks/payments", data=body, headers={"X-Signature": sign(body)})
    assert resp.status_code == 200
    assert "Essentiel" in client.get("/billing").get_data(as_text=True)
    assert "/calendar/" in client.get("/settings").get_data(as_text=True)


def test_webhook_unconfigured_is_refused(tmp_path):
    from app import create_app
    app = create_app({"ECHEO_DATA_DIR": str(tmp_path), "WEBHOOK_SECRET": ""})
    assert app.test_client().post("/webhooks/payments", data=b"{}").status_code == 503


# --------------------------------------------------------------- agenda, RGPD
def test_calendar_feed_requires_paid_or_trial_and_is_valid(app, client):
    login(client, app)
    add_deadline(client, title="Visa, très important; urgent", days=40)
    token = conn_of(app).execute("SELECT cal_token FROM users").fetchone()[0]
    resp = client.get(f"/calendar/{token}.ics")
    text = resp.get_data(as_text=True)
    assert resp.status_code == 200 and text.startswith("BEGIN:VCALENDAR")
    assert "SUMMARY:Visa\\, très important\\; urgent (Alice)" in text
    assert client.get("/calendar/invalide.ics").status_code == 404
    conn = conn_of(app)
    conn.execute("UPDATE users SET trial_ends_at=?", (iso_in(-1),))
    conn.commit()
    assert client.get(f"/calendar/{token}.ics").status_code == 404


def test_export_contains_user_data(app, client):
    login(client, app)
    add_deadline(client, title="Assurance")
    data = json.loads(client.get("/settings/export").get_data(as_text=True))
    assert data["compte"]["email"] == "alice@example.com"
    assert data["echeances"][0]["title"] == "Assurance"


def test_security_headers_and_health(client):
    resp = client.get("/")
    assert resp.headers["X-Frame-Options"] == "DENY"
    assert "default-src 'self'" in resp.headers["Content-Security-Policy"]
    assert client.get("/healthz").get_json()["ok"] is True


def test_kpis_compute(app, client):
    login(client, app)
    for i in range(3):
        add_deadline(client, title=f"E{i}")
    k = kpis.compute(conn_of(app))
    assert k["inscrits_total"] == 1 and k["activation_pct"] == 100.0 and k["mrr_usd"] == 0
