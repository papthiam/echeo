#!/usr/bin/env python3
"""Tableau de bord KPI en ligne de commande : python kpis.py"""
from datetime import date, datetime, timedelta, timezone

import db as dbm
from config import load_config
from plans import monthly_value


def parse_ts(value):
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def compute(conn, today=None):
    today = today or date.today()
    users = conn.execute("SELECT * FROM users").fetchall()
    week_ago = datetime.now(timezone.utc) - timedelta(days=7)

    new_7d = sum(1 for u in users if parse_ts(u["created_at"]) >= week_ago)
    activated = 0
    for u in users:
        limit = (parse_ts(u["created_at"]) + timedelta(hours=48)).strftime("%Y-%m-%dT%H:%M:%SZ")
        n = conn.execute(
            "SELECT COUNT(*) FROM deadlines WHERE user_id=? AND created_at<=?", (u["id"], limit)
        ).fetchone()[0]
        activated += 1 if n >= 3 else 0

    paying = [u for u in users if u["plan"] in ("essential", "family") and u["paid_until"] and u["paid_until"] >= today.isoformat()]
    mrr = sum(monthly_value(u["plan"], u["plan_interval"]) for u in paying)
    trial_over = [u for u in users if u["trial_ends_at"] < today.isoformat()]
    converted = [u for u in trial_over if u in paying]

    since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ")
    sent = conn.execute("SELECT COUNT(*) FROM reminders_sent WHERE status='sent' AND sent_at>=?", (since,)).fetchone()[0]
    return {
        "inscrits_total": len(users),
        "inscrits_7j": new_7d,
        "activation_pct": round(100 * activated / len(users), 1) if users else 0.0,
        "abonnes_payants": len(paying),
        "mrr_usd": round(mrr, 2),
        "essais_termines": len(trial_over),
        "conversion_essai_pct": round(100 * len(converted) / len(trial_over), 1) if trial_over else 0.0,
        "rappels_envoyes_30j": sent,
    }


def main():
    cfg = load_config()
    dbm.init_db(cfg["DB_PATH"])
    conn = dbm.connect(cfg["DB_PATH"])
    k = compute(conn)
    print("KPI Échéo")
    print(f"  Inscrits : {k['inscrits_total']} (dont {k['inscrits_7j']} sur 7 jours)")
    print(f"  Activation (>= 3 échéances en 48 h) : {k['activation_pct']} % — cible > 40 %")
    print(f"  Abonnés payants : {k['abonnes_payants']}")
    print(f"  MRR : {k['mrr_usd']} $ — objectif 500 $")
    print(f"  Conversion essai -> payant : {k['conversion_essai_pct']} % ({k['essais_termines']} essais terminés) — cible > 15 %")
    print(f"  Rappels envoyés (30 j) : {k['rappels_envoyes_30j']}")


if __name__ == "__main__":
    main()
