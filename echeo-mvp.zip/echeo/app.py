"""Échéo : suivi des échéances administratives (MVP).

Lancement local :  python app.py
Production      :  gunicorn "app:create_app()"
"""
import hashlib
import hmac
import io
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta, timezone
from functools import wraps

from cryptography.fernet import Fernet, InvalidToken
from flask import (
    Flask, Response, abort, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for,
)

import db as dbm
from catalog import CATEGORIES, MODEL_BY_KEY, MODELS, REMIND_CHOICES, VALID_REMIND
from config import DEFAULT_REMIND, load_config
from mailer import send_email
from plans import PLANS, effective_plan

EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[^@\s]{2,}$")
MAX_FILE = 10 * 1024 * 1024
MAX_FILES_PER_DEADLINE = 10
LOGIN_TTL_MIN = 15
LOGIN_PER_EMAIL_PER_HOUR = 5
LOGIN_GLOBAL_PER_HOUR = 300
SIGNATURES = {
    ".pdf": (b"%PDF-",),
    ".png": (b"\x89PNG\r\n\x1a\n",),
    ".jpg": (b"\xff\xd8\xff",),
    ".jpeg": (b"\xff\xd8\xff",),
}
MIMES = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}
CSRF_EXEMPT = {"webhook", "unsubscribe", "healthz", "static"}


def utcnow():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def normalize_email(raw):
    email = (raw or "").strip().lower()
    if len(email) > 254 or not EMAIL_RE.match(email):
        return None
    return email


def ics_escape(text):
    return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def ics_fold(line):
    out, data = [], line.encode("utf-8")
    while len(data) > 75:
        cut = 75
        while (data[cut] & 0xC0) == 0x80:
            cut -= 1
        out.append(data[:cut].decode("utf-8"))
        data = b" " + data[cut:]
    out.append(data.decode("utf-8"))
    return "\r\n".join(out)


def create_app(env=None):
    cfg = load_config(env)
    app = Flask(__name__)
    app.config.update(cfg)
    app.config.update(
        MAX_CONTENT_LENGTH=MAX_FILE + 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=timedelta(days=30),
    )
    dbm.init_db(cfg["DB_PATH"])
    fernet = Fernet(cfg["FILE_KEY"].encode())

    # ------------------------------------------------------------------ outils
    def get_db():
        if "db" not in g:
            g.db = dbm.connect(app.config["DB_PATH"])
        return g.db

    @app.teardown_appcontext
    def close_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def create_user(conn, email):
        now = utcnow()
        trial_end = (now.date() + timedelta(days=app.config["TRIAL_DAYS"])).isoformat()
        cur = conn.execute(
            "INSERT INTO users (email, created_at, trial_ends_at, cal_token, unsub_token) VALUES (?,?,?,?,?)",
            (email, iso(now), trial_end, secrets.token_urlsafe(24), secrets.token_urlsafe(24)),
        )
        dbm.track(conn, cur.lastrowid, "signup")
        return cur.lastrowid

    def user_dir(user_id):
        path = os.path.join(app.config["UPLOAD_DIR"], str(user_id))
        os.makedirs(path, exist_ok=True)
        return path

    def purge_files(rows, user_id):
        for row in rows:
            try:
                os.remove(os.path.join(app.config["UPLOAD_DIR"], str(user_id), row["stored_name"]))
            except FileNotFoundError:
                pass

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("login"))
            return view(*args, **kwargs)

        return wrapped

    def get_deadline(did):
        row = get_db().execute(
            "SELECT * FROM deadlines WHERE id=? AND user_id=?", (did, g.user["id"])
        ).fetchone()
        if row is None:
            abort(404)
        return row

    # ----------------------------------------------------- sécurité transverse
    @app.before_request
    def csrf_protect():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(24)
        if request.method == "POST" and request.endpoint not in CSRF_EXEMPT:
            sent = request.form.get("csrf", "")
            if not hmac.compare_digest(sent, session["csrf"]):
                abort(400)

    @app.before_request
    def load_user():
        g.user, g.plan, g.plan_state = None, "free", "free"
        uid = session.get("uid")
        if uid:
            row = get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            if row:
                g.user = row
                g.plan, g.plan_state = effective_plan(row)
            else:
                session.pop("uid", None)

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; style-src 'self'; form-action 'self'; frame-ancestors 'none'"
        )
        if request.endpoint not in ("static",):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        trial_left = None
        if g.get("user") is not None and g.plan_state == "trial":
            trial_left = (date.fromisoformat(g.user["trial_ends_at"]) - date.today()).days
        return {
            "user": g.get("user"),
            "plan": g.get("plan", "free"),
            "plan_state": g.get("plan_state", "free"),
            "plan_label": PLANS[g.get("plan", "free")]["label"],
            "trial_left": trial_left,
            "csrf": session.get("csrf", ""),
            "categories": CATEGORIES,
            "legal_entity": app.config["LEGAL_ENTITY"],
            "contact_email": app.config["CONTACT_EMAIL"],
        }

    @app.template_filter("fr_date")
    def fr_date(value):
        return date.fromisoformat(value).strftime("%d/%m/%Y")

    @app.template_filter("delta")
    def delta(left):
        if left < -1:
            return f"En retard de {-left} jours"
        if left == -1:
            return "En retard d'1 jour"
        if left == 0:
            return "Aujourd'hui"
        if left == 1:
            return "Demain"
        if left < 60:
            return f"Dans {left} jours"
        months = round(left / 30.4)
        if months < 24:
            return f"Dans {months} mois"
        return f"Dans {round(left / 365)} ans"

    @app.template_filter("size_h")
    def size_h(n):
        return f"{n / 1024:.0f} Ko" if n < 1024 * 1024 else f"{n / 1024 / 1024:.1f} Mo"

    def error_page(code, message):
        return render_template("error.html", code=code, message=message), code

    @app.errorhandler(400)
    def e400(_e):
        return error_page(400, "Requête invalide. Si votre session a expiré, rechargez la page et réessayez.")

    @app.errorhandler(404)
    def e404(_e):
        return error_page(404, "Page introuvable.")

    @app.errorhandler(413)
    def e413(_e):
        return error_page(413, "Fichier trop volumineux (10 Mo maximum).")

    # ------------------------------------------------------------ pages publiques
    @app.route("/")
    def index():
        if g.user:
            return redirect(url_for("dashboard"))
        return render_template("index.html", plans=PLANS)

    @app.route("/page/<name>")
    def legal(name):
        if name not in ("confidentialite", "conditions"):
            abort(404)
        return render_template("legal.html", name=name)

    @app.get("/healthz")
    def healthz():
        get_db().execute("SELECT 1")
        path = os.path.join(app.config["DATA_DIR"], "last_reminder_run")
        last, stale = None, None
        try:
            with open(path, "r", encoding="utf-8") as f:
                last = f.read().strip()
            when = datetime.strptime(last, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            stale = (utcnow() - when) > timedelta(hours=26)
        except (FileNotFoundError, ValueError):
            pass
        return jsonify(ok=True, reminders_last_run=last, reminders_stale=stale)

    # ------------------------------------------------------------ authentification
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("dashboard"))
        if request.method == "GET":
            return render_template("login.html")

        email = normalize_email(request.form.get("email"))
        if not email:
            flash("Adresse email invalide.", "error")
            return render_template("login.html"), 400

        conn = get_db()
        hour_ago = iso(utcnow() - timedelta(hours=1))
        global_count = conn.execute(
            "SELECT COUNT(*) FROM login_tokens WHERE created_at >= ?", (hour_ago,)
        ).fetchone()[0]
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        user_id = user["id"] if user else None
        recent = 0
        if user_id:
            recent = conn.execute(
                "SELECT COUNT(*) FROM login_tokens WHERE user_id=? AND created_at >= ?", (user_id, hour_ago)
            ).fetchone()[0]

        if global_count < LOGIN_GLOBAL_PER_HOUR and recent < LOGIN_PER_EMAIL_PER_HOUR:
            if user_id is None:
                user_id = create_user(conn, email)
            token = secrets.token_urlsafe(32)
            now = utcnow()
            conn.execute(
                "INSERT INTO login_tokens (user_id, token_hash, created_at, expires_at) VALUES (?,?,?,?)",
                (user_id, hash_token(token), iso(now), iso(now + timedelta(minutes=LOGIN_TTL_MIN))),
            )
            conn.commit()
            link = f"{app.config['BASE_URL']}/auth/{token}"
            text = (
                "Bonjour,\n\n"
                f"Voici votre lien de connexion à Échéo (valable {LOGIN_TTL_MIN} minutes, utilisable une seule fois) :\n\n"
                f"{link}\n\n"
                "Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.\n\n— Échéo"
            )
            send_email(app.config, email, "Votre lien de connexion Échéo", text)
        # Réponse identique dans tous les cas : on ne révèle pas si un compte existe.
        return redirect(url_for("check_email"))

    @app.get("/check-email")
    def check_email():
        return render_template("check_email.html", minutes=LOGIN_TTL_MIN)

    @app.route("/auth/<token>", methods=["GET", "POST"])
    def auth(token):
        conn = get_db()
        row = conn.execute(
            "SELECT * FROM login_tokens WHERE token_hash=?", (hash_token(token),)
        ).fetchone()
        valid = bool(row and row["used_at"] is None and row["expires_at"] > iso(utcnow()))
        if request.method == "GET":
            # Simple confirmation : les scanners d'emails qui ouvrent le lien ne consomment pas le jeton.
            return render_template("auth_confirm.html", valid=valid)
        if not valid:
            flash("Ce lien n'est plus valable. Demandez-en un nouveau.", "error")
            return redirect(url_for("login"))
        used = conn.execute(
            "UPDATE login_tokens SET used_at=? WHERE id=? AND used_at IS NULL", (iso(utcnow()), row["id"])
        ).rowcount
        if used != 1:
            flash("Ce lien a déjà été utilisé.", "error")
            return redirect(url_for("login"))
        dbm.track(conn, row["user_id"], "login")
        conn.commit()
        session.clear()
        session["uid"] = row["user_id"]
        session["csrf"] = secrets.token_urlsafe(24)
        session.permanent = True
        return redirect(url_for("dashboard"))

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("index"))

    # -------------------------------------------------------------------- échéances
    def parse_deadline_form(form):
        errors = []
        title = (form.get("title") or "").strip()
        if not 1 <= len(title) <= 120:
            errors.append("Le titre est obligatoire (120 caractères maximum).")
        category = form.get("category", "autre")
        if category not in CATEGORIES:
            category = "autre"
        notes = (form.get("notes") or "").strip()
        if len(notes) > 2000:
            errors.append("Les notes sont limitées à 2000 caractères.")
        due_raw = (form.get("due_date") or "").strip()
        try:
            due = date.fromisoformat(due_raw)
            if not date(2000, 1, 1) <= due <= date.today() + timedelta(days=365 * 20):
                errors.append("La date est hors limites.")
        except ValueError:
            errors.append("Date invalide (format AAAA-MM-JJ).")
        chosen = sorted(
            {int(x) for x in form.getlist("remind") if x.isdigit() and int(x) in VALID_REMIND}, reverse=True
        )
        remind = ",".join(str(x) for x in chosen) or DEFAULT_REMIND
        data = {
            "title": title,
            "category": category,
            "country": (form.get("country") or "").strip()[:60],
            "person": (form.get("person") or "").strip()[:60],
            "due_date": due_raw,
            "remind_days": remind,
            "notes": notes,
        }
        return data, errors

    def form_context(data, errors, mode, did=None):
        data = dict(data)
        data["remind_set"] = {int(x) for x in data["remind_days"].split(",") if x.strip().isdigit()}
        return render_template(
            "deadline_form.html", d=data, errors=errors, mode=mode, did=did,
            remind_choices=REMIND_CHOICES, models=MODELS,
        )

    @app.get("/dashboard")
    @login_required
    def dashboard():
        rows = get_db().execute(
            "SELECT * FROM deadlines WHERE user_id=? ORDER BY due_date", (g.user["id"],)
        ).fetchall()
        today = date.today()
        late, soon, later, done = [], [], [], []
        for r in rows:
            item = dict(r)
            item["left"] = (date.fromisoformat(r["due_date"]) - today).days
            if r["done"]:
                done.append(item)
            elif item["left"] < 0:
                late.append(item)
            elif item["left"] <= 30:
                soon.append(item)
            else:
                later.append(item)
        active = len(late) + len(soon) + len(later)
        limit = PLANS[g.plan]["max_deadlines"]
        at_limit = limit is not None and active >= limit
        return render_template(
            "dashboard.html", late=late, soon=soon, later=later, done=done, at_limit=at_limit, limit=limit
        )

    @app.route("/deadlines/new", methods=["GET", "POST"])
    @login_required
    def deadline_new():
        conn = get_db()
        limit = PLANS[g.plan]["max_deadlines"]
        if limit is not None:
            active = conn.execute(
                "SELECT COUNT(*) FROM deadlines WHERE user_id=? AND done=0", (g.user["id"],)
            ).fetchone()[0]
            if active >= limit:
                flash(f"Le plan gratuit est limité à {limit} échéances actives. Passez à Essentiel pour en ajouter.", "error")
                return redirect(url_for("billing"))
        if request.method == "POST":
            data, errors = parse_deadline_form(request.form)
            if errors:
                return form_context(data, errors, "new"), 400
            cur = conn.execute(
                "INSERT INTO deadlines (user_id, title, category, country, person, due_date, remind_days, notes, created_at)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (g.user["id"], data["title"], data["category"], data["country"], data["person"],
                 data["due_date"], data["remind_days"], data["notes"], dbm.utc_iso()),
            )
            dbm.track(conn, g.user["id"], "deadline_created")
            conn.commit()
            flash("Échéance ajoutée. Vous serez prévenu(e) par email aux dates choisies.", "ok")
            return redirect(url_for("deadline_detail", did=cur.lastrowid))
        model = MODEL_BY_KEY.get(request.args.get("model", ""))
        data = {
            "title": model["title"] if model else "",
            "category": model["category"] if model else "autre",
            "country": "", "person": "", "due_date": "", "notes": "",
            "remind_days": model["remind_days"] if model else DEFAULT_REMIND,
        }
        return form_context(data, [], "new")

    @app.get("/deadlines/<int:did>")
    @login_required
    def deadline_detail(did):
        d = dict(get_deadline(did))
        d["left"] = (date.fromisoformat(d["due_date"]) - date.today()).days
        d["remind_labels"] = [label for days, label in REMIND_CHOICES if str(days) in d["remind_days"].split(",")]
        files = get_db().execute(
            "SELECT * FROM attachments WHERE deadline_id=? ORDER BY id", (did,)
        ).fetchall()
        return render_template("deadline_detail.html", d=d, files=files, storage_mb=PLANS[g.plan]["storage_mb"])

    @app.route("/deadlines/<int:did>/edit", methods=["GET", "POST"])
    @login_required
    def deadline_edit(did):
        row = get_deadline(did)
        if request.method == "POST":
            data, errors = parse_deadline_form(request.form)
            if errors:
                return form_context(data, errors, "edit", did), 400
            # Une nouvelle date = un renouvellement : l'échéance redevient active et les rappels se réarment.
            done = 0 if data["due_date"] != row["due_date"] else row["done"]
            conn = get_db()
            conn.execute(
                "UPDATE deadlines SET title=?, category=?, country=?, person=?, due_date=?, remind_days=?, notes=?, done=?"
                " WHERE id=? AND user_id=?",
                (data["title"], data["category"], data["country"], data["person"], data["due_date"],
                 data["remind_days"], data["notes"], done, did, g.user["id"]),
            )
            conn.commit()
            flash("Échéance mise à jour.", "ok")
            return redirect(url_for("deadline_detail", did=did))
        return form_context(dict(row), [], "edit", did)

    @app.post("/deadlines/<int:did>/done")
    @login_required
    def deadline_done(did):
        row = get_deadline(did)
        conn = get_db()
        conn.execute("UPDATE deadlines SET done=? WHERE id=?", (0 if row["done"] else 1, did))
        conn.commit()
        return redirect(url_for("deadline_detail", did=did))

    @app.post("/deadlines/<int:did>/delete")
    @login_required
    def deadline_delete(did):
        get_deadline(did)
        conn = get_db()
        files = conn.execute("SELECT * FROM attachments WHERE deadline_id=?", (did,)).fetchall()
        purge_files(files, g.user["id"])
        conn.execute("DELETE FROM deadlines WHERE id=? AND user_id=?", (did, g.user["id"]))
        conn.commit()
        flash("Échéance supprimée.", "ok")
        return redirect(url_for("dashboard"))

    # ------------------------------------------------------------- pièces jointes
    @app.post("/deadlines/<int:did>/upload")
    @login_required
    def upload(did):
        get_deadline(did)
        quota = PLANS[g.plan]["storage_mb"] * 1024 * 1024
        if quota == 0:
            flash("Le stockage de documents est inclus dans les plans Essentiel et Famille.", "error")
            return redirect(url_for("billing"))
        f = request.files.get("file")
        if f is None or not f.filename:
            flash("Choisissez un fichier.", "error")
            return redirect(url_for("deadline_detail", did=did))
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in SIGNATURES:
            flash("Formats acceptés : PDF, JPG, PNG.", "error")
            return redirect(url_for("deadline_detail", did=did))
        data = f.read(MAX_FILE + 1)
        if len(data) > MAX_FILE:
            flash("Fichier trop volumineux (10 Mo maximum).", "error")
            return redirect(url_for("deadline_detail", did=did))
        if not any(data.startswith(sig) for sig in SIGNATURES[ext]):
            flash("Le contenu du fichier ne correspond pas à son format.", "error")
            return redirect(url_for("deadline_detail", did=did))
        conn = get_db()
        used = conn.execute("SELECT COALESCE(SUM(size),0) FROM attachments WHERE user_id=?", (g.user["id"],)).fetchone()[0]
        count = conn.execute("SELECT COUNT(*) FROM attachments WHERE deadline_id=?", (did,)).fetchone()[0]
        if used + len(data) > quota:
            flash("Espace de stockage insuffisant pour votre plan.", "error")
            return redirect(url_for("deadline_detail", did=did))
        if count >= MAX_FILES_PER_DEADLINE:
            flash(f"{MAX_FILES_PER_DEADLINE} documents maximum par échéance.", "error")
            return redirect(url_for("deadline_detail", did=did))
        stored = secrets.token_hex(16)
        with open(os.path.join(user_dir(g.user["id"]), stored), "wb") as out:
            out.write(fernet.encrypt(data))
        name = re.sub(r"[^\w.\- ]", "_", os.path.basename(f.filename))[:100] or "document" + ext
        conn.execute(
            "INSERT INTO attachments (deadline_id, user_id, filename, stored_name, size, created_at) VALUES (?,?,?,?,?,?)",
            (did, g.user["id"], name, stored, len(data), dbm.utc_iso()),
        )
        dbm.track(conn, g.user["id"], "upload")
        conn.commit()
        flash("Document ajouté (stocké chiffré).", "ok")
        return redirect(url_for("deadline_detail", did=did))

    def get_attachment(aid):
        row = get_db().execute(
            "SELECT * FROM attachments WHERE id=? AND user_id=?", (aid, g.user["id"])
        ).fetchone()
        if row is None:
            abort(404)
        return row

    @app.get("/files/<int:aid>")
    @login_required
    def download(aid):
        att = get_attachment(aid)
        path = os.path.join(app.config["UPLOAD_DIR"], str(g.user["id"]), att["stored_name"])
        try:
            with open(path, "rb") as f:
                data = fernet.decrypt(f.read())
        except (FileNotFoundError, InvalidToken):
            abort(404)
        ext = os.path.splitext(att["filename"])[1].lower()
        return send_file(
            io.BytesIO(data), mimetype=MIMES.get(ext, "application/octet-stream"),
            as_attachment=True, download_name=att["filename"],
        )

    @app.post("/files/<int:aid>/delete")
    @login_required
    def attachment_delete(aid):
        att = get_attachment(aid)
        purge_files([att], g.user["id"])
        conn = get_db()
        conn.execute("DELETE FROM attachments WHERE id=?", (aid,))
        conn.commit()
        flash("Document supprimé.", "ok")
        return redirect(url_for("deadline_detail", did=att["deadline_id"]))

    # -------------------------------------------------------- abonnement et webhook
    @app.get("/billing")
    @login_required
    def billing():
        return render_template(
            "billing.html", plans=PLANS, checkout=app.config["CHECKOUT_URLS"],
            paid_until=g.user["paid_until"], interval=g.user["plan_interval"],
        )

    @app.post("/webhooks/payments")
    def webhook():
        """Reçoit les événements de votre prestataire de paiement.

        Format attendu (à adapter côté prestataire ou via un petit mapping) :
        {"event": "subscription_active" | "subscription_expired", "email": "...",
         "plan": "essential" | "family", "interval": "month" | "year",
         "paid_until": "AAAA-MM-JJ", "customer_ref": "..."}
        En-tête X-Signature : HMAC-SHA256 hexadécimal du corps brut avec WEBHOOK_SECRET.
        """
        secret = app.config["WEBHOOK_SECRET"]
        if not secret:
            return jsonify(error="webhook non configuré"), 503
        raw = request.get_data()
        expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(request.headers.get("X-Signature", ""), expected):
            return jsonify(error="signature invalide"), 401
        try:
            payload = json.loads(raw)
            event = payload["event"]
            email = normalize_email(payload.get("email"))
        except (ValueError, KeyError, TypeError):
            return jsonify(error="corps invalide"), 400
        if not email:
            return jsonify(error="email invalide"), 400

        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        user_id = user["id"] if user else create_user(conn, email)

        if event == "subscription_active":
            plan = payload.get("plan")
            interval = payload.get("interval", "month")
            try:
                paid_until = date.fromisoformat(payload.get("paid_until", "")).isoformat()
            except ValueError:
                return jsonify(error="paid_until invalide"), 400
            if plan not in ("essential", "family") or interval not in ("month", "year"):
                return jsonify(error="plan ou intervalle invalide"), 400
            conn.execute(
                "UPDATE users SET plan=?, plan_interval=?, paid_until=?, customer_ref=COALESCE(?, customer_ref) WHERE id=?",
                (plan, interval, paid_until, payload.get("customer_ref"), user_id),
            )
            dbm.track(conn, user_id, "payment_active")
        elif event == "subscription_expired":
            yesterday = (date.today() - timedelta(days=1)).isoformat()
            conn.execute("UPDATE users SET paid_until=? WHERE id=?", (yesterday, user_id))
            dbm.track(conn, user_id, "subscription_expired")
        else:
            return jsonify(error="événement inconnu"), 400
        conn.commit()
        return jsonify(ok=True)

    # ------------------------------------------------------- réglages, RGPD, agenda
    @app.route("/settings", methods=["GET", "POST"])
    @login_required
    def settings():
        conn = get_db()
        if request.method == "POST":
            enabled = 1 if request.form.get("reminders_enabled") else 0
            conn.execute("UPDATE users SET reminders_enabled=? WHERE id=?", (enabled, g.user["id"]))
            conn.commit()
            flash("Réglages enregistrés.", "ok")
            return redirect(url_for("settings"))
        cal_url = None
        if g.plan != "free":
            cal_url = f"{app.config['BASE_URL']}/calendar/{g.user['cal_token']}.ics"
        return render_template("settings.html", cal_url=cal_url)

    @app.get("/settings/export")
    @login_required
    def settings_export():
        conn = get_db()
        uid = g.user["id"]
        payload = {
            "compte": {k: g.user[k] for k in ("email", "created_at", "plan", "plan_interval", "paid_until", "reminders_enabled")},
            "echeances": [dict(r) for r in conn.execute("SELECT * FROM deadlines WHERE user_id=?", (uid,))],
            "documents": [
                {k: r[k] for k in ("deadline_id", "filename", "size", "created_at")}
                for r in conn.execute("SELECT * FROM attachments WHERE user_id=?", (uid,))
            ],
        }
        body = json.dumps(payload, ensure_ascii=False, indent=2)
        return Response(
            body, mimetype="application/json",
            headers={"Content-Disposition": "attachment; filename=echeo-mes-donnees.json"},
        )

    @app.post("/settings/delete-account")
    @login_required
    def settings_delete():
        if (request.form.get("confirm_email") or "").strip().lower() != g.user["email"]:
            flash("L'adresse saisie ne correspond pas à votre compte.", "error")
            return redirect(url_for("settings"))
        conn = get_db()
        uid = g.user["id"]
        purge_files(conn.execute("SELECT * FROM attachments WHERE user_id=?", (uid,)).fetchall(), uid)
        conn.execute("DELETE FROM events WHERE user_id=?", (uid,))
        conn.execute("DELETE FROM users WHERE id=?", (uid,))
        conn.commit()
        session.clear()
        flash("Votre compte et toutes vos données ont été supprimés.", "ok")
        return redirect(url_for("index"))

    @app.get("/calendar/<token>.ics")
    def calendar(token):
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE cal_token=?", (token,)).fetchone()
        if user is None or effective_plan(user)[0] == "free":
            abort(404)
        stamp = utcnow().strftime("%Y%m%dT%H%M%SZ")
        lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Echeo//FR", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Échéo"]
        for r in conn.execute("SELECT * FROM deadlines WHERE user_id=? AND done=0 ORDER BY due_date", (user["id"],)):
            start = date.fromisoformat(r["due_date"])
            summary = r["title"] + (f" ({r['person']})" if r["person"] else "")
            lines += [
                "BEGIN:VEVENT",
                f"UID:echeo-{r['id']}@echeo",
                f"DTSTAMP:{stamp}",
                f"DTSTART;VALUE=DATE:{start:%Y%m%d}",
                f"DTEND;VALUE=DATE:{start + timedelta(days=1):%Y%m%d}",
                f"SUMMARY:{ics_escape(summary)}",
                "END:VEVENT",
            ]
        lines.append("END:VCALENDAR")
        body = "\r\n".join(ics_fold(line) for line in lines) + "\r\n"
        return Response(body, mimetype="text/calendar; charset=utf-8")

    @app.route("/unsubscribe/<token>", methods=["GET", "POST"])
    def unsubscribe(token):
        conn = get_db()
        user = conn.execute("SELECT id FROM users WHERE unsub_token=?", (token,)).fetchone()
        if user is None:
            abort(404)
        if request.method == "POST":
            conn.execute("UPDATE users SET reminders_enabled=0 WHERE id=?", (user["id"],))
            conn.commit()
            return render_template("unsubscribed.html")
        return render_template("unsubscribe.html", token=token)

    return app


if __name__ == "__main__":
    create_app().run(debug=os.environ.get("FLASK_DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
